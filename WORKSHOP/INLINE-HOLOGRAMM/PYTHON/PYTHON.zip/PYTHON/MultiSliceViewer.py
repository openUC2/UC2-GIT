# -*- coding: utf-8 -*-
"""
Created on Wed Oct 10 17:00:01 2018

@author: diederichbenedict
"""

from __future__ import print_function

import numpy as np
import matplotlib.pyplot as plt

# Taken from this link: https://matplotlib.org/2.1.2/gallery/animation/image_slices_viewer.html

class IndexTracker(object):
    def __init__(self, ax, X):
        self.ax = ax
        ax.set_title('use scroll wheel to navigate images')

        self.X = X
        rows, cols, self.slices = X.shape
        self.ind = self.slices//2

        self.im = ax.imshow(self.X[:, :, self.ind])
        self.update()

    def onscroll(self, event):
        print("%s %s" % (event.button, event.step))
        if event.button == 'up':
            self.ind = (self.ind + 1) % self.slices
        else:
            self.ind = (self.ind - 1) % self.slices
        self.update()

    def update(self):
        self.im.set_data(self.X[:, :, self.ind])
        ax.set_ylabel('slice %s' % self.ind)
        self.im.axes.figure.canvas.draw()


