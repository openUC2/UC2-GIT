/*
 * To the extent possible under law, the ImageJ developers have waived
 * all copyright and related or neighboring rights to this tutorial code.
 *
 * See the CC0 1.0 Universal license for details:
 *     http://creativecommons.org/publicdomain/zero/1.0/
 */

package de.uc2.nanoimaging;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.math3.util.FastMath;
//import org.apache.commons.math3.complex.Complex;
import org.scijava.command.Command;
import org.scijava.io.IOService;
import org.scijava.plugin.Parameter;
import org.scijava.plugin.Plugin;
import org.scijava.plugin.PluginService;
import org.scijava.ui.UIService;

import ij.IJ;
import ij.ImagePlus;
import ij.WindowManager;
import ij.plugin.FFT;
import io.scif.services.DatasetIOService;
import net.imagej.Dataset;
import net.imagej.DatasetService;
import net.imagej.ImageJ;
import net.imagej.ops.OpService;
import net.imglib2.Cursor;
import net.imglib2.IterableInterval;
import net.imglib2.RandomAccess;
import net.imglib2.RandomAccessibleInterval;
import net.imglib2.img.Img;
import net.imglib2.img.ImgFactory;
import net.imglib2.img.array.ArrayImgFactory;
import net.imglib2.img.display.imagej.ImageJFunctions;
import net.imglib2.loops.LoopBuilder;
import net.imglib2.type.Type;
import net.imglib2.type.numeric.RealType;
import net.imglib2.type.numeric.complex.ComplexFloatType;
import net.imglib2.type.numeric.real.FloatType;
import net.imglib2.util.Util;
import net.imglib2.view.Views;


@Plugin(type = Command.class, menuPath = "Plugins>DIHM")
public class DIHM<T extends RealType<T>> implements Command {

	@Parameter
	private Dataset currentData;
	@Parameter
	private UIService uiService;
	@Parameter
	private OpService opService;
	@Parameter
	private IOService ioService;
	@Parameter
	private DatasetService dsService;
	@Parameter
	private DatasetIOService dsioService;
	@Parameter
	private PluginService pluginService;
	
	private final float pixelsize = (float) 1.4e-6;
	private final float lambda0 = (float) 440e-9;
	private final float stepsize = (float) 0.0001;
	private final int nsteps = 70;
	//private final float upsample_scale = 1.0;
	private final ComplexFloatType j = new ComplexFloatType(0, 1);
	private long ld_min = 0;
	
	public static String workingDir;
	
	final public static <T extends Type<T> & Comparable<T>> T getImageMax(
			final RandomAccessibleInterval<T> img ) {
		
		final Cursor<T> cursor = Views.iterable(img).cursor();
		cursor.fwd();
		
		final T max = cursor.get().copy();

		while ( cursor.hasNext() )
		{
			cursor.fwd();

			final T currValue = cursor.get();

			if ( currValue.compareTo( max ) > 0 )
				max.set( currValue );
		}

	    return max;
	}
	
	final public static <T extends Type<T> & Comparable<T>> T getImageMin(
			final RandomAccessibleInterval<T> img )
	{
		final Cursor<T> cursor = Views.iterable(img).cursor();
		cursor.fwd();
		// copy first element as current maximum
		final T min = cursor.get().copy();

		while ( cursor.hasNext() )
		{
			cursor.fwd();

			final T currValue = cursor.get();

			if ( currValue.compareTo( min ) < 0 )
				min.set( currValue );
		}
	    return min;
	 }
	
	public Img<T> getNormalizedFloatImg(RandomAccessibleInterval<T> input){
		
		Img<T> normalizedOutput = createEmptyFloatImg(input);
		T max = getImageMax(input);
		RandomAccess<T> randomAccess = normalizedOutput.randomAccess();
		
		final Cursor<T> cursor = Views.iterable(input).cursor();
		T val;
		
		while ( cursor.hasNext() )
		{
			cursor.fwd();
			randomAccess.setPosition( cursor );
			val = cursor.get();
			randomAccess.get().setReal(val.getRealFloat() / max.getRealFloat());
		}
		return normalizedOutput;
	}
	
	public void mywait(int milliseconds) {
		try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        }
	}
	
	public Img<T> myFFT(){
		//computes log of FFT-Powerspectrum of most recently active image window 
		//acts as if the internal plugin was run by user, thus the plugin shows it
		
		FFT fft = new FFT();
        FFT.displayComplex = true;
        fft.run("fft");
        
        Img<T> fft_img = null;
        
        String[] allTitles = WindowManager.getImageTitles();     
        for(String title : allTitles) {
             if (title.indexOf("Complex") != -1) {
            	 fft_img = getWindowImgFloat(title);
             }
        }
        WindowManager.closeAllWindows();
		return fft_img;
	}
	
	public void myInvFFT(Img<T> G_phase, RandomAccessibleInterval<T> ifft_out){
		
		hackedFFT ifft_complex = new hackedFFT();
		ImagePlus phases = ImageJFunctions.wrap(G_phase, "Complex Phases");
		Img<T> invG_phase = (Img<T>)ImageJFunctions.wrap(ifft_complex.doComplexInverseTransform(phases));
		
		RandomAccessibleInterval<T> real = null;
		RandomAccessibleInterval<T> imag = null;
		real = Views.offsetInterval(invG_phase, new long[] { 0, 0, 0 }, new long[] { ld_min, ld_min, 1 });
		imag = Views.offsetInterval(invG_phase, new long[] { 0, 0, 1 }, new long[] { ld_min, ld_min, 1 });

		Cursor<T> cursorReal = Views.iterable(real).localizingCursor();
		RandomAccess<T> imag_randomAccess = imag.randomAccess();
		RandomAccess<T> ifft_randomAccess = ifft_out.randomAccess();

		float re = 0;
		float im = 0;
		float abs = 0;

		while (cursorReal.hasNext()) {
			
			cursorReal.fwd();

			imag_randomAccess.setPosition(cursorReal);
			ifft_randomAccess.setPosition(cursorReal);

			re = cursorReal.get().getRealFloat();
			im = imag_randomAccess.get().getRealFloat();
			abs = (float) FastMath.sqrt(re * re + im * im);

			ifft_randomAccess.get().setReal(abs);
		}
	}
	
	public Img<T> getAmplitude(final RandomAccessibleInterval<T> img ) {
		
		Img<T> amplitude = (Img<T>)Util.getSuitableImgFactory(img, new FloatType(0)).create(img);
		RandomAccess< T > randomAccess = amplitude.randomAccess();
		
		final Cursor<T> cursor = Views.iterable(img).cursor();
		float tmp = 0;
		
		while ( cursor.hasNext() )
		{
			cursor.fwd();
			randomAccess.setPosition( cursor );
			T currValue = cursor.get();
			tmp = (float) FastMath.sqrt(currValue.getRealFloat());
			randomAccess.get().setReal(tmp);
		}
	    return amplitude;
	}
	
	public int binlog(int bits) {
		
		//determine next lower binary logarithm to passed int via bitshifts
		int log = 0;
		if ((bits & 0xffff0000) != 0) {
			bits >>>= 16;
			log = 16;
		}
		if (bits >= 256) {
			bits >>>= 8;
			log += 8;
		}
		if (bits >= 16) {
			bits >>>= 4;
			log += 4;
		}
		if (bits >= 4) {
			bits >>>= 2;
			log += 2;
		}
		return log + (bits >>> 1);
	}
	
	public ImagePlus copyRAItoImagePlus(RandomAccessibleInterval<T> sourceRAI) {
		return ImageJFunctions.wrap(sourceRAI, "wrapped");
	}
	public ImagePlus create3DImagePlus(int x, int y, int z, String title) {
		return IJ.createImage("New empty ImagePlus", "32-bit black", x, y, z);
	}
	public Img<T> createEmptyImg(RandomAccessibleInterval<T> sourceRAI) {
		return Util.getSuitableImgFactory(sourceRAI, Util.getTypeFromInterval(sourceRAI)).create(sourceRAI);
	}
	public Img<T> createEmptyFloatImg(RandomAccessibleInterval<T> sourceRAI) {
		return (Img<T>)Util.getSuitableImgFactory(sourceRAI, new FloatType(0)).create(sourceRAI);
	}
	public Img<T> getActiveImg(){
		return (Img<T>) ImageJFunctions.wrap(IJ.getImage());
	}
	public Img<T> getActiveImgFloat(){
		return (Img<T>) ImageJFunctions.convertFloat(IJ.getImage());
	}
	public Img<T> getWindowImg(String title){
		return (Img<T>) ImageJFunctions.wrap(WindowManager.getImage(title));
	}
	public Img<T> getWindowImgFloat(String title){
		//return (Img<T>) ImageJFunctions.convertFloat(WindowManager.getImage(title));
		return (Img<T>) ImageJFunctions.wrapReal(WindowManager.getImage(title));
	}
	public Img<T> copyRAItoImg(RandomAccessibleInterval<T> sourceRAI) {
		Img<T> targetImg = (Img<T>) opService.run(net.imagej.ops.create.img.CreateImgFromRAI.class, sourceRAI);
		opService.run(net.imagej.ops.copy.CopyRAI.class, targetImg, sourceRAI);
		return targetImg;
	}
	public Img<T> copyRAItoImg_2(RandomAccessibleInterval<T> sourceRAI) {
		Img<T> target = createEmptyImg(sourceRAI);
		LoopBuilder.setImages(target, sourceRAI).forEachPixel(Type::set);
		return target;
	}	
	public Img<FloatType> copyRAItoFloatImg(RandomAccessibleInterval<T> sourceRAI) {
		return opService.convert().float32((IterableInterval<T>)sourceRAI);
	}
	public Img<T> createEmpty3DImg(int[] dims){
		ImagePlus imp = create3DImagePlus(dims[0], dims[1], dims[2], "imp");
		return ImageJFunctions.wrapReal(imp);
	}
	
	public void FresnelPropagator(RandomAccessibleInterval<T> E0){
		
		final int pad = (int)((ld_min-1) / 2);
		final float inv_grid_size = 1 / (pixelsize * ld_min);
		final float freqXY_strt = -pad * inv_grid_size;
		final int[] iFFT_dims = new int[] { (int) ld_min, (int) ld_min, nsteps };
		
		final Img<T> E = getNormalizedFloatImg(E0);
		ImageJFunctions.show(E, "E0 (Normalized)");
		
		Img<T> E_fft = myFFT();
		Img<T> G_phase = (Img<T>) opService.create().img(E_fft);
		
		RandomAccessibleInterval<T> E_fft_real;
		RandomAccessibleInterval<T> E_fft_imag;
		RandomAccessibleInterval<T> G_phase_real;
		RandomAccessibleInterval<T> G_phase_imag;
		
		E_fft_real = Views.offsetInterval( E_fft, new long[] {0, 0, 0}, new long[] {ld_min, ld_min, 1});
		E_fft_imag = Views.offsetInterval( E_fft, new long[] {0, 0, 1}, new long[] {ld_min, ld_min, 1});
		G_phase_real = Views.offsetInterval( G_phase, new long[] {0, 0, 0}, new long[] {ld_min, ld_min, 1});
		G_phase_imag = Views.offsetInterval( G_phase, new long[] {0, 0, 1}, new long[] {ld_min, ld_min, 1});
		
		
		ImgFactory<T> imgFactory = (ImgFactory<T>) new ArrayImgFactory<FloatType>();
		RandomAccessibleInterval<T> iFFT = (RandomAccessibleInterval<T>)imgFactory.create(iFFT_dims, Util.getTypeFromInterval(E));

		float xpos = 0;
		float ypos = 0;
		float zpos = 0;
		
		float k = (float) (2 * FastMath.PI / lambda0);
		float p = (float) (Math.PI * lambda0);
		
		ComplexFloatType h = new ComplexFloatType(0, 0);
		ComplexFloatType H = new ComplexFloatType(0, 0);		
		ComplexFloatType G = new ComplexFloatType(0, 0);
		
		float re = 0;
		float im = 0;	
		float Fxx = 0;
		float Fyy = 0;
		double arg = 0;

		Cursor<T> cursorE = Views.iterable(E).localizingCursor();
		
		long[] slice_strt = new long[] {0, 0, 1};
		long[] slice_offset = new long[] {ld_min, ld_min, 1};
		
		for (int z=1; z <= nsteps; z++) {
			
			slice_strt[2] = z-1;
			slice_offset[2] = z;
			zpos = stepsize * z;
			
			RandomAccessibleInterval<T> iFFT_slice = null;
			iFFT_slice = Views.offsetInterval( iFFT, slice_strt, slice_offset);
			
			RandomAccess<T> FFT_real_randomAccess = E_fft_real.randomAccess();
			RandomAccess<T> FFT_imag_randomAccess = E_fft_imag.randomAccess();
			RandomAccess<T> Phase_real_randomAccess = G_phase_real.randomAccess();
			RandomAccess<T> Phase_imag_randomAccess = G_phase_imag.randomAccess();
					
			while ( cursorE.hasNext() )
			{
			   cursorE.fwd();
			   
			   FFT_real_randomAccess.setPosition(cursorE);
			   FFT_imag_randomAccess.setPosition(cursorE);
			   Phase_real_randomAccess.setPosition(cursorE);
			   Phase_imag_randomAccess.setPosition(cursorE);
			   
			   xpos = cursorE.getFloatPosition(0);
			   ypos = cursorE.getFloatPosition(1);
			   
			   Fxx = freqXY_strt + xpos * inv_grid_size;
			   Fyy = freqXY_strt + ypos * inv_grid_size;
			   Fxx = Fxx * Fxx;
			   Fyy = Fyy * Fyy;
			   
			   
			   arg = k * zpos;
			   H.set((float) FastMath.cos(arg), (float) FastMath.sin(arg));
			   arg = -p * zpos * (Fxx + Fyy);
			   h.set((float)FastMath.cos(arg), (float) FastMath.sin(arg));
			   H.mul(h);
			   
			   re = FFT_real_randomAccess.get().getRealFloat();
			   im = FFT_imag_randomAccess.get().getRealFloat();
			   
			   G.set(re, im);
			   G.mul(H);
			   
			   Phase_real_randomAccess.get().setReal(G.getRealFloat());
			   Phase_imag_randomAccess.get().setReal(G.getImaginaryFloat());
			}
			System.out.println("Processed Z-position: " + String.format("%.04f", zpos));
			myInvFFT(G_phase, iFFT_slice);
			cursorE.reset();
		}
		ImageJFunctions.show(iFFT, "Backpropagation of Hologram");
	  }	

	@Override
	public void run() {
        
        Img<T> orig_img = (Img<T>) currentData.getImgPlus();
		int ndims = orig_img.numDimensions();	
		long[] dims = new long[ndims];
		
		orig_img.dimensions(dims);
		
		ArrayList<Integer> log2_dims = new ArrayList<>();
		
		for (long item : dims) {
			log2_dims.add( (int)FastMath.pow(2, binlog((int)item)) ); 
		}
		
		List<Integer> xy_plane = log2_dims.subList(0, 1);
		ld_min = Collections.min(xy_plane);
		
		long x = (dims[0] - ld_min) / 2;
		long y = (dims[1] - ld_min) / 2;
		
		//crop image
		RandomAccessibleInterval<T> view;
		//RandomAccessibleInterval<T> bg;
		
		if (ndims>2) {
			long[] crop_start = new long[] { x, y, dims[ndims-1]};
			long[] crop_length = new long[] { ld_min, ld_min, 1};
			view = Views.offsetInterval( orig_img, crop_start, crop_length );
			//bg = Views.offsetInterval( background_img, crop_start, crop_length );
		}
		else {
			long[] crop_start = new long[] { x, y };
			long[] crop_length = new long[] { ld_min, ld_min };
			view = Views.offsetInterval( orig_img, crop_start, crop_length );
			//bg = Views.offsetInterval(background_img, crop_start, crop_length );
		}
		
		//ImageJFunctions.show(view);
		FresnelPropagator(view);
	}

	public static void main(final String... args) throws Exception {
		// create the ImageJ application context with all available services
		final ImageJ ij = new ImageJ();
		ij.ui().showUI();

		// ask the user for a file to open
		final File file = ij.ui().chooseFile(null, "open");

		if (file != null) {
			//save chosen directory as current working directory
			workingDir = file.getParent();

			// load the dataset
			Dataset dataset = ij.scifio().datasetIO().open(file.getPath());

			// show the image
			ij.ui().show(dataset);
		    		    
			// invoke the plugin
			ij.command().run(DIHM.class, true);
		}
	}
}